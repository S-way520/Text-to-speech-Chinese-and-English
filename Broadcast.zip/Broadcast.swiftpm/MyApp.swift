import SwiftUI
@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(TextSay: "物体的空间位置随时间的变化，是自然界中最简单、最基本的运动形态， 叫作机械运动 (mechanical motion)。")
        }
    }
}
